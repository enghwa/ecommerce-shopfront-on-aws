const axios = require('axios');

exports.handler = async function (event) {
  const URL = "https://esi0tzo6d1.execute-api.ap-southeast-1.amazonaws.com/prod/"

  let post_response = await axios.post(URL, {
    sds: event['sds'],
    dns: event['ns']
  }).then(function (post_response) {
    console.log(post_response.data)
  })
    .catch(function (error) {
      console.log(error)
    })

  const response = {
    statusCode: 200,
    body: JSON.stringify({ message: 'Updated: ' + event['sds'] })
  }
  return response
}
//'ns-1525.awsdns-62.org, ns-295.awsdns-36.com, ns-565.awsdns-06.net, ns-1832.awsdns-37.co.uk'